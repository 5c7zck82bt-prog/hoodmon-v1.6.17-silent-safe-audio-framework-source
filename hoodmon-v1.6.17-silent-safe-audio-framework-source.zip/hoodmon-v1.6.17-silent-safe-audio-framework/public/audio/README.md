# HOODMON Audio Asset Gate

This directory intentionally contains **no playable audio files** in v1.6.17.

Before adding any music, SFX, voice, or UI sound:

1. Confirm the asset may be used commercially in a game/app.
2. Prefer original/self-generated audio made specifically for HOODMON, or clearly documented CC0/public-domain material.
3. Do not add ripped game/movie/anime/social-media audio, copyrighted songs, free-plan MusicGPT generations, or audio with unclear "royalty-free" terms.
4. Add a record to `LICENSE_MANIFEST.json` containing the cue, filename, creator/source, license, proof/receipt location, generation date if applicable, and any attribution requirement.
5. Only after documentation is complete, add the file path and matching `licenseId` to `src/audio/audioRegistry.ts`, then set `approvedForCommercialUse: true`.

The runtime requires **all three** before playback: a source path, a license ID, and explicit commercial-use approval.

A null `src` in the registry is a deliberate safety lock: that cue remains silent.
